# Omaima Yasir - Software Engineer Portfolio

## Overview

This is a modern, cinematic portfolio website for Omaima Yasir, a software engineering undergraduate student. The site showcases a professional dark-themed design with glassmorphism effects, 3D animations, and smooth user interactions. Built with vanilla HTML, CSS, and JavaScript, it features dynamic particle backgrounds, parallax scrolling, and responsive design optimized for all devices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Pure Web Technologies**: Built entirely with vanilla HTML5, CSS3, and JavaScript without frameworks
- **Single Page Application**: All content loads on a single page with smooth scroll navigation between sections
- **Component-Based Structure**: Modular approach with separate navigation, hero, about, skills, projects, education, and contact sections
- **Mobile-First Design**: Responsive layout with hamburger menu for mobile devices and desktop navigation

### Visual Design System
- **Dark Theme Foundation**: Primary background using `hsl(240, 21%, 7%)` with layered secondary backgrounds
- **Glassmorphism UI**: Semi-transparent components with subtle borders and backdrop blur effects
- **CSS Custom Properties**: Centralized design tokens in `:root` for consistent theming and easy maintenance
- **Gradient System**: Multiple gradient presets for primary, secondary, and accent elements
- **Typography Scale**: Inter font family with weights 100-900 and responsive sizing hierarchy

### Animation & Interaction System
- **Canvas-Based Particle System**: HTML5 Canvas with 100 floating particles for dynamic background
- **Intersection Observer API**: Implements scroll-triggered animations and section transitions
- **CSS Transform Animations**: 3D hover effects with `translateY` and `scale` transforms
- **Smooth Scrolling**: Browser-native smooth scroll behavior for navigation
- **Responsive Animations**: Mobile-optimized animation performance with reduced motion options

### Component Architecture
- **Fixed Navigation**: Glassmorphism header with smooth scroll links and mobile hamburger menu
- **Hero Section**: Large gradient typography with call-to-action buttons
- **Skills Grid**: Three-column layout with animated progress bars and category-based organization
- **Toast Notification System**: Fixed-position feedback system for user interactions
- **Mobile Menu Overlay**: Full-screen navigation overlay for mobile devices

## External Dependencies

### Fonts & Icons
- **Google Fonts**: Inter font family (weights 100-900) for consistent typography
- **Font Awesome 6.0.0**: Icon library via CDN for social media and UI icons
- **Preconnect Optimization**: DNS prefetching for Google Fonts domains for improved performance

### Browser APIs
- **HTML5 Canvas API**: For particle system rendering and animation
- **Intersection Observer API**: For scroll-triggered animations and lazy loading
- **Resize Observer**: For responsive canvas and layout adjustments
- **CSS Custom Properties**: For dynamic theming and responsive design variables

### Performance Optimizations
- **CSS Preloading**: Font display optimization with `display=swap`
- **CDN Integration**: External resources loaded from CDNs for improved caching
- **Responsive Images**: Optimized loading for different screen sizes
- **Hardware Acceleration**: CSS transforms using GPU acceleration for smooth animations